# swaggerize-express-rest-api

Swagger api [location](./config/swagger.json)
